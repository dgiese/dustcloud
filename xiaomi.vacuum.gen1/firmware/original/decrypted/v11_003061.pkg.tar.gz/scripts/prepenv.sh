#!/bin/sh

RR_ROOT=/opt/rockrobo
RR_UDATA=/mnt/data
RR_DEFAULT=/mnt/default
RR_RESERVE=/mnt/reserve

WIFI_START_PATH=$RR_ROOT/wlan
WIFI_START_NAME=wifi_start.sh

WIFI_CONF_PATH=$RR_UDATA/miio
WIFI_CONF_NAME=wifi.conf

WIFI_ENABLE_PATH=$RR_UDATA/wlan
WIFI_ENABLE_NAME=wifi_enable.conf

MIIO_RECV_LINE=miio_recv_line
MIIO_SEND_LINE=miio_send_line

NAV_CONFIG_PATH=$RR_ROOT/cleaner/conf 
NAV_DYNAMIC_CONFIG_PATH=$RR_UDATA/rockrobo 
NAV_LOG_PATH=$RR_UDATA/rockrobo

# Directory for saving downloaded update package and related files
UPDPKG_DIR=$RR_UDATA/.temp

# Full path for update info file
UPDPKG_INFO_PATH=$UPDPKG_DIR
UPDPKG_INFO_NAME=Update.pkg.inf

# append some apps location to the system PATH virable.
PATH=$PATH:$RR_ROOT/rrlog:$RR_ROOT/cleaner/bin:$RR_ROOT/wlan:$RR_ROOT/watchdog:$RR_ROOT/miio:$RR_ROOT/firmware

# export the following to global
export RR_ROOT
export RR_UDATA
export RR_DEFAULT
export RR_RESERVE

export WIFI_START_PATH
export WIFI_START_NAME

export WIFI_CONF_PATH
export WIFI_CONF_NAME

export WIFI_ENABLE_PATH
export WIFI_ENABLE_NAME

export MIIO_PATH 
export MIIO_RECV
export MIIO_SEND

export NAV_CONFIG_PATH
export NAV_DYNAMIC_CONFIG_PATH
export NAV_LOG_PATH

export UPDPKG_INFO_PATH
export UPDPKG_INFO_NAME


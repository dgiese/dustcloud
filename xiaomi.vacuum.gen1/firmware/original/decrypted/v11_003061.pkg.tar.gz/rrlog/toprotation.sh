#!/bin/bash
top -H -d 15 -b >>/dev/shm/topHtmp.log &
top -d 5 -b >>/dev/shm/toptmp.log &
FILEH=/dev/shm/topHtmp.log
FILE=/dev/shm/toptmp.log
FLASHLOG=/mnt/data/rockrobo/rrlog
NO=0
HNO=0
while :; do
FILE_SIZE=`du $FILE | awk '{print $1}'`
FILEH_SIZE=`du $FILEH | awk '{print $1}'`
#echo $FILE_SIZE
#echo $FILEH_SIZE

if [ $FILEH_SIZE -gt 1024 ]
then
HNO=`expr $HNO + 1`
echo "$FILEH greater than 1M"
cp $FILEH $FLASHLOG/topH.$HNO.log
echo "" > $FILEH
nice -n 19 gzip -f $FLASHLOG/topH.$HNO.log
fi

if [ $FILE_SIZE -gt 1024 ]
then
NO=`expr $NO + 1`
echo "$FILE greater than 1M"
cp $FILE $FLASHLOG/top.$NO.log
echo "" > $FILE
nice -n 19 gzip -f $FLASHLOG/top.$NO.log
fi
sleep 60
done

#!/bin/bash
set -x
mkdir -p /mnt/data/rockrobo/rrlog
cd /mnt/data/rockrobo/rrlog
nice -n 19 gzip core.*

cd /var/log
nice -n 19 tar zcf $RR_UDATA/rockrobo/rrlog/varlog.tar.gz ./*
rm -rf *.gz
rm -rf *.0
rm -rf *.1
rm -rf *.2
rm -rf *.3
echo "" > /var/log/syslog
echo "" > /var/log/kern.log

cd /dev/shm
nice -n 19 gzip -c misc.log > $RR_UDATA/rockrobo/rrlog/misc.gz
rm -rf /dev/shm/misc.log
nice -n 19 gzip -c $RR_UDATA/rockrobo/rrlog/watchdog.log > $RR_UDATA/rockrobo/rrlog/watchdog.gz
echo "" > $RR_UDATA/rockrobo/rrlog/watchdog.log
nice -n 19 gzip -c /mnt/data/rockrobo/rrlog/rrlog.log > $RR_UDATA/rockrobo/rrlog/rrlog.gz
echo "" > $RR_UDATA/rockrobo/rrlog/rrlog.log
nice -n 19 gzip -c $RR_UDATA/rockrobo/rrlog/miio.log > $RR_UDATA/rockrobo/rrlog/miio.gz
echo "" > $RR_UDATA/rockrobo/rrlog/miio.log
cd /opt/rockrobo
nice -n 19 tar zcf $RR_UDATA/rockrobo/rrlog/version.tar.gz ./buildnumber ./version_info.txt
cd /mnt/data/rockrobo/
nice -n 19 tar zcf /mnt/data/rockrobo/rrlog/mt_test.tar.gz MtNavLog.* mtlog.*
rm MtNavLog.*
rm mtlog.*
cd /mnt/data/rockrobo/rrlog
nice -n 19 gzip uart_test.log
nice -n 19 gzip uart_test_command.txt
nice -n 19 gzip uart_test_lds_data.log

#!/bin/bash
set -x
cd /dev/shm
mkdir -p /mnt/data/rockrobo/rrlog 
cp topHtmp.log /mnt/data/rockrobo/rrlog/topH.last.log
echo "" > topHtmp.log
nice -n 19 gzip -f /mnt/data/rockrobo/rrlog/topH.last.log

cp toptmp.log /mnt/data/rockrobo/rrlog/top.last.log
echo "" > toptmp.log
nice -n 19 gzip -f /mnt/data/rockrobo/rrlog/top.last.log

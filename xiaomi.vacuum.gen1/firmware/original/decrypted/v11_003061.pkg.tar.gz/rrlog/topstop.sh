#!/bin/bash
set -x
mkdir -p /mnt/data/rockrobo/rrlog
killall toprotation.sh
killall top
cd /dev/shm
gzip -f topHtmp.log
gzip -f toptmp.log
mv  topHtmp.log.gz /mnt/data/rockrobo/rrlog
mv  toptmp.log.gz /mnt/data/rockrobo/rrlog

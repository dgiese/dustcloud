#!/bin/bash
/opt/rockrobo/rrlog/toprotation.sh &

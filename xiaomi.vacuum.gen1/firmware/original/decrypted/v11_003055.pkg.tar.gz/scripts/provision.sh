#!/bin/sh

rm -f $RR_UDATA/miio/device.conf
if [ ! -f "$RR_UDATA/miio/device.conf" ]; then
	ln -s $RR_DEFAULT/device.conf $RR_UDATA/miio/device.conf
fi

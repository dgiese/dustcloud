#!/bin/bash

pipe=/tmp/RcNv
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/RcAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/RcMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/RcUp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/RcLg
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
fi

		
pipe=/tmp/RcWd
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/RcWm
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/RcLr
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi	

pipe=/tmp/RcCs
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi	
	
pipe=/tmp/NvRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/NvAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/NvMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi
		
pipe=/tmp/NvLg
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/NvSl
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi	

pipe=/tmp/NvLr
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/NvCs
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi	

pipe=/tmp/ApRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi
		
pipe=/tmp/ApNv
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/ApMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/ApUp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi
		
pipe=/tmp/ApLg
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/ApWm
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/ApSl
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/ApLr
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi
	
pipe=/tmp/McRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi
	
pipe=/tmp/McNv
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/McAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/McLg
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/McWd
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/McWm
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/McSl
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/McLr
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/McCs
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/UpRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/UpAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi
	
pipe=/tmp/UpLg
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/UpWd
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi


pipe=/tmp/LgRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/LgNv
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/LgAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/LgMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/LgUp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WdRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WdMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WdUp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WdWm
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WmRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WmAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WmMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WmWd
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/SlNv
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/SlAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/SlMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/SlSl
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi


pipe=/tmp/LrRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/LrNv
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/LrAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/LrMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi	

pipe=/tmp/LrCs
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/CsRc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/CsNv
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi	

pipe=/tmp/CsMc
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi	

pipe=/tmp/CsLr
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/WdAp
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi

pipe=/tmp/ApWd
if [[ ! -p $pipe ]]; then
    mkfifo $pipe
	chmod 0666 $pipe
fi


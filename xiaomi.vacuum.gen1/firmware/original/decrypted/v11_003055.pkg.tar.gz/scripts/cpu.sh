#!/bin/bash 
### BEGIN INIT INFO 
### END INIT INFO 

if [ "$1" = "" ] ; then 
echo "####################################" 
echo "ondemand : Dynamically switch between CPU(s) available if at 95% cpu load" 
echo "performance: Run the cpu at max frequency" 
echo "conservative: Dynamically switch between CPU(s) available if at 75% load" 
echo "powersave: Run the cpu at the minimum frequency" 
echo "userspace: Run the cpu at user specified frequencies" 
echo "" 
echo "example ./cpu.sh performance" 
echo "####################################" 
exit 
fi 

# setup all cpu 
for CPUFREQ in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor 
do 
[ -f $CPUFREQ ] || continue 
echo -n $1 > $CPUFREQ 
done 

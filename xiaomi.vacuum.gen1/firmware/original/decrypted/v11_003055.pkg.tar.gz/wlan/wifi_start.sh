#!/bin/bash


DEVICE_CONF=/mnt/default/device.conf
WIFI_CONFIG_FILE=/mnt/data/miio/wifi.conf
SET_MAC=""
SET_CHANNEL_PLAN=""
wifi_module="8189es"
WIFI_DIR=/mnt/data/wlan
WPA_CONF=/mnt/data/wlan/wpa_supplicant.conf
TMP_WPA_CONF=/tmp/wpa_supplicant.conf.gbk
INTERFACES_STA_CONF=/mnt/data/wlan/interfaces

channel=1

debug_mode=0
clear_sevice=0
wifi_need_insmod=true

while getopts "dcn" name
do
	case $name in
		d)
			debug_mode=1;
			;;
		c)
			clear_sevice=1;
			;;
		n)
			wifi_need_insmod=false;
			;;
	esac
done
set_led ()
{
	command="led0 $1"
	if [ -f /sys/bus/platform/devices/rr_leds/rrleds ]; then
		echo -n "$command" > /sys/bus/platform/devices/rr_leds/rrleds
	fi
}

wifi_adjust_channel()
{
	ifconfig wlan0 up

	cstr=`iw wlan0 scan -u | grep freq:`
	local c1=`echo $cstr | grep -o 2412 | wc -l`
	local c6=`echo $cstr | grep -o 2437 | wc -l`
	local c11=`echo $cstr | grep -o 2462 | wc -l`

	if [ $c1 -lt $c6 ]
	then
		if [ $c1 -lt $c11 ]
		then
			channel=1
		else
			channel=11
		fi
	else
		if [ $c6 -lt $c11 ]
		then
			channel=6
		else
			channel=11
		fi
	fi
}

wifi_ap_mode()
{
	# AP mode

	if [ -f $DEVICE_CONF ]; then
		prefix=`grep model= $DEVICE_CONF | cut -d '=' -f2 | sed -e 's/\./-/g'`
	else
		prefix="noconfig"
	fi

	suffix=`echo $1 | tr '[:lower:]' '[:upper:]'`
	ssid_ap=$prefix"_miap"$suffix
	CMD="create_ap -c $channel -n wlan0 -g 192.168.8.1 $ssid_ap --daemon"
	echo "set wifi ap mode"
	if [ $debug_mode -eq 1 ];then
		${CMD}
	else
		${CMD} >/dev/null 2>&1
	fi
	set_led ap
	sleep 1
}

wifi_sta_mode()
{
	if [ ! -f ${INTERFACES_STA_CONF} ]; then
		echo auto lo wlan0                      >  ${INTERFACES_STA_CONF}
		echo iface lo inet loopback             >> ${INTERFACES_STA_CONF}
		echo iface wlan0 inet dhcp             	>> ${INTERFACES_STA_CONF}
		echo wpa-conf ${WPA_CONF}             	>> ${INTERFACES_STA_CONF}
	fi
	SSID=`cat ${WIFI_CONFIG_FILE} | grep ^ssid| sed 's/ssid=//g'`
	PASSWD=`cat ${WIFI_CONFIG_FILE} | grep ^psk| sed 's/psk=//g'`
	if [ -z "$PASSWD" ]; then
		echo "network={"						> $WPA_CONF
		echo "       ssid=$SSID" 			>> $WPA_CONF
		echo "       key_mgmt=NONE" 			>> $WPA_CONF
		echo "}" 								>> $WPA_CONF
	else
		#wpa_passphrase "$SSID" "$PASSWD" > $WPA_CONF
		echo "ap_scan=1"				>  $WPA_CONF
		echo "network={"				>> $WPA_CONF
		echo "       ssid=$SSID" 			>> $WPA_CONF
		echo "       scan_ssid=1"               	>> $WPA_CONF
		echo "       psk=$PASSWD" 			>> $WPA_CONF
		echo "}" 					>> $WPA_CONF
	fi

	rm -f ${TMP_WPA_CONF}
        iconv -f UTF-8 -t GBK ${WPA_CONF} -o ${TMP_WPA_CONF}

	if [ $? -eq 0 ]; then
		ret=`diff ${WPA_CONF} ${TMP_WPA_CONF}`
		if [ $? == 1 ]; then
			cat ${TMP_WPA_CONF} | grep -v "ap_scan" >> ${WPA_CONF}
		fi
	fi

	# STA mode
	CMD="ifup wlan0 -i ${INTERFACES_STA_CONF}"
	echo "set wifi sta mode"
	set_led blink
	if [ $debug_mode -eq 1 ];then
		${CMD}
	else
		${CMD} >/dev/null 2>&1
	fi
	if [ $? -eq 0 ]; then
		 set_led blink
	fi
}
prepare()
{
	set_led off
	ifdown wlan0 > /dev/null 2>&1
	ifconfig wlan0 down > /dev/null 2>&1
	killall hostapd >/dev/null 2>&1
	iw mon.wlan0 del >/dev/null 2>&1
	create_ap --stop wlan0 > /dev/null 2>&1
	killall wpa_supplicant >/dev/null 2>&1
	killall dhclient >/dev/null 2>&1
	if [ -e $DEVICE_CONF ]; then
		SET_MAC=`cat $DEVICE_CONF | grep mac | cut -d '=' -f 2`
	fi
	if [ -e /mnt/reserve/rockrobo.conf ]; then
		LOCATION=`cat /mnt/reserve/rockrobo.conf |grep -i "^[[:space:]]*location[[:space:]]*=" |sed -e 's/^.*=[[:space:]]*//' |sed -e 's/[[:space:]]*$//'`
		if [ "x$LOCATION" = "xtw" ]; then
			SET_CHANNEL_PLAN="0x39"
		fi
	fi
}

start()
{
	while $wifi_need_insmod ; do
		if [ -z "$SET_MAC" ]; then
			ifconfig wlan0 >/dev/null 2>&1
			if [ $? -eq 0 ]; then
				wifi_need_insmod=false
				break;
			fi
		else
			wlan0_is_set_macd=`ifconfig wlan0 2>/dev/null | grep -wic $SET_MAC`
			if [ $wlan0_is_set_macd -gt 0 ]; then
				wifi_need_insmod=false
				break;
			fi
		fi
		has_insmod=`lsmod | grep -wc "^$wifi_module"`
		if [ $has_insmod -gt 0 ]; then
			rmmod $wifi_module -f
			rm /etc/udev/rules.d/70-persistent-net.rules -rf
		fi
		wifi_module_with_path=`find /lib/modules/ -name ${wifi_module}.ko`
		if [ -z "${wifi_module_with_path}" ]; then
			echo can not find wifi modules
			return -1
		fi
		if [ -z "$SET_MAC" ]; then
			if [ -z "$SET_CHANNEL_PLAN" ]; then
				insmod ${wifi_module_with_path}
			else
				insmod ${wifi_module_with_path} rtw_channel_plan=$SET_CHANNEL_PLAN
			fi
		else
			if [ -z "$SET_CHANNEL_PLAN" ]; then
				insmod ${wifi_module_with_path} rtw_initmac=$SET_MAC
			else
				insmod ${wifi_module_with_path} rtw_initmac=$SET_MAC rtw_channel_plan=$SET_CHANNEL_PLAN
			fi
		fi
		sleep 2
	done
	if [ -e $WIFI_CONFIG_FILE ]; then
		has_ssid=`cat $WIFI_CONFIG_FILE | grep -v \^# | grep -wc ssid`
		if [ $has_ssid -gt 0 ]; then
			wifi_sta_mode
			return 0
		else
			rm $WIFI_CONFIG_FILE -rf
		fi
	fi
	STRING=`ifconfig wlan0`
	macstring=${STRING##*HWaddr }
	macstring=`echo ${macstring} | cut -d ' ' -f 1`

	mac1=`echo ${macstring} | cut -d ':' -f 5`
	mac2=`echo ${macstring} | cut -d ':' -f 6`
	MAC=${mac1}${mac2}
	wifi_adjust_channel
	wifi_ap_mode $MAC
}
if [ ! -d ${WIFI_DIR} ]; then
	mkdir -p ${WIFI_DIR}
fi

if [ $clear_sevice -eq 1 ]; then
        prepare
else
        #if wifi_need_insmod = false, it is called by wlanmgr, then
        #don't need to call prepare because wlanmgr had called "wifi_start.sh -cn"
        if  $wifi_need_insmod ; then
                prepare
        fi
fi

if [ $clear_sevice -eq 1 ]; then
	if  $wifi_need_insmod ; then
		rmmod $wifi_module >/dev/null 2>&1
	fi
	exit 0
fi
start

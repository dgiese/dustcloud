#!/bin/bash
date >> /dev/shm/misc.log
cat /dev/jiffies >> /dev/shm/misc.log
echo "=======/proc/interrupts==========" >> /dev/shm/misc.log
cat /proc/interrupts >> /dev/shm/misc.log
echo "=======/proc/softirqs==========" >> /dev/shm/misc.log
cat /proc/softirqs >> /dev/shm/misc.log
echo "=======dmesg==========" >> /dev/shm/misc.log
dmesg >> /dev/shm/misc.log
echo "=======netstat -na==========" >> /dev/shm/misc.log
netstat -na -p>> /dev/shm/misc.log
echo "=======/proc/meminfo==========" >> /dev/shm/misc.log
cat /proc/meminfo >> /dev/shm/misc.log
#echo "=======/proc/vmallocinfo==========" >> /dev/shm/misc.log
#cat /proc/vmallocinfo >> /dev/shm/misc.log
echo "=======/proc/vmstat==========" >> /dev/shm/misc.log
cat /proc/vmstat >> /dev/shm/misc.log
echo "=======/proc/slabinfo==========" >> /dev/shm/misc.log
cat /proc/slabinfo >> /dev/shm/misc.log
echo "=======/proc/zoneinfo==========" >> /dev/shm/misc.log
cat /proc/zoneinfo >> /dev/shm/misc.log
echo "=======/proc/pagetypeinfo==========" >> /dev/shm/misc.log
cat /proc/pagetypeinfo >> /dev/shm/misc.log
echo "=======/sys/devices/system/cpu/cpu0/cpufreq/stats/time_in_state==========" >> /dev/shm/misc.log
cat /sys/devices/system/cpu/cpu0/cpufreq/stats/time_in_state >> /dev/shm/misc.log
echo "=======/sys/devices/system/cpu/cpu1/cpufreq/stats/time_in_state==========" >> /dev/shm/misc.log
cat /sys/devices/system/cpu/cpu1/cpufreq/stats/time_in_state >> /dev/shm/misc.log
echo "=======/sys/devices/system/cpu/cpu2/cpufreq/stats/time_in_state==========" >> /dev/shm/misc.log
cat /sys/devices/system/cpu/cpu2/cpufreq/stats/time_in_state >> /dev/shm/misc.log
echo "=======/sys/devices/system/cpu/cpu3/cpufreq/stats/time_in_state==========" >> /dev/shm/misc.log
cat /sys/devices/system/cpu/cpu3/cpufreq/stats/time_in_state >> /dev/shm/misc.log
echo "=======ifconfig -a==========" >> /dev/shm/misc.log
ifconfig -a >> /dev/shm/misc.log
echo "=======df -h==========" >> /dev/shm/misc.log
df -h >> /dev/shm/misc.log
echo "=======lsof==========" >> /dev/shm/misc.log
lsof / >> /dev/shm/misc.log
lsof /dev >> /dev/shm/misc.log
lsof /tmp >> /dev/shm/misc.log
lsof /run >> /dev/shm/misc.log
lsof /run/lock >> /dev/shm/misc.log
lsof /run/shm >> /dev/shm/misc.log
lsof /mnt/updbuf >> /dev/shm/misc.log
lsof /mnt/data >> /dev/shm/misc.log
lsof /mnt/reserve >> /dev/shm/misc.log
lsof /mnt/default >> /dev/shm/misc.log
echo "=======uart.0 info==========" >> /dev/shm/misc.log
cat /sys/devices/platform/uart.0/ctrl_info >> /dev/shm/misc.log
cat /sys/devices/platform/uart.0/status >> /dev/shm/misc.log
echo "=======uart.1 info==========" >> /dev/shm/misc.log
cat /sys/devices/platform/uart.1/ctrl_info >> /dev/shm/misc.log
cat /sys/devices/platform/uart.1/status >> /dev/shm/misc.log
echo "=======uart.2 info==========" >> /dev/shm/misc.log
cat /sys/devices/platform/uart.2/ctrl_info >> /dev/shm/misc.log
cat /sys/devices/platform/uart.2/status >> /dev/shm/misc.log
echo "=======device.conf==========" >> /dev/shm/misc.log
cat /mnt/default/device.conf >> /dev/shm/misc.log